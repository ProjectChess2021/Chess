This is a chess project for University of Waterloo CS 246 F21 final project. Colaborated by Kunling Yang, Zichu Wu, and Min Kim.
